# Currencies ETL using Yandex Cloud

# 